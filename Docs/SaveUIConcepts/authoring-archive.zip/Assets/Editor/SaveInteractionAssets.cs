using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

// Export existing sprite slices for the browser interaction study; no generated replacement art.
public static class SaveInteractionAssets
{
    public static void Export()
    {
        const string output="Docs/SaveUIConcepts/motion/assets";
        Directory.CreateDirectory(output);
        var sprites=AssetDatabase.LoadAllAssetsAtPath("Assets/Art/Textures/UI.psd").OfType<Sprite>().ToArray();
        foreach(var name in new[]{"UI_Panel","UI_HoveredFrame","UI_NameTooltip"}) Write(sprites.First(s=>s.name==name),output+"/"+name+".png");
        foreach(var place in new[]{"驾驶室","动力舱","维生舱","飞船外壳"})
        {
            var data=AssetDatabase.LoadAssetAtPath<PlaceData>("Assets/Resources/ScriptableObject/Place/"+place+".asset");
            Write(data.placeImage,output+"/"+place+".png");
        }
        File.Copy("Assets/Art/Font/tianwangxingxiangsu.ttf",output+"/pixel.ttf",true);
        File.WriteAllText(output+"/sources.txt","UI_Panel: UI.psd slice 32x33 border 5; UI_HoveredFrame: UI.psd slice 24x24 border 4; UI_NameTooltip: UI.psd slice 30x14 border 4.\nPlace sprites: Resources/ScriptableObject/Place/*.asset placeImage.\nFont: Art/Font/tianwangxingxiangsu.ttf\nAccent: #64DEAE; warning: ColorManager.Red #FF403B.\n");
        if(Application.isBatchMode)EditorApplication.Exit(0);
    }
    private static void Write(Sprite sprite,string path)
    {
        var texture=sprite.texture;
        var rt=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
        Graphics.Blit(texture,rt);
        var before=RenderTexture.active;RenderTexture.active=rt;
        var r=sprite.textureRect;
        var result=new Texture2D((int)r.width,(int)r.height,TextureFormat.RGBA32,false);
        result.ReadPixels(r,0,0);result.Apply();File.WriteAllBytes(path,result.EncodeToPNG());
        RenderTexture.active=before;RenderTexture.ReleaseTemporary(rt);Object.DestroyImmediate(result);
    }
}
