using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

// Separate design studies. These prefabs deliberately do not read or change player saves.
public static class SaveUIConcepts
{
    private static readonly Color Accent = new Color32(100,222,174,255);
    private static readonly Color Muted = new Color32(158,158,158,255);
    private static Font font;
    private static Sprite panel, frame;
    private static RectTransform root;
    private static readonly string[] Places = { "驾驶舱", "动力舱", "维生舱", "驾驶舱", "飞船外壳", "动力舱" };
    private static readonly string[] Times = { "第14天 14:30", "第14天 14:20", "第14天 12:05", "第13天 23:10", "第13天 18:40", "第13天 16:20" };
    private static readonly string[] Kinds = { "手动", "自动", "退出", "手动", "自动", "自动" };
    private static readonly string[] RealTimes = { "09/18 14:30", "09/18 14:20", "09/18 13:45", "09/17 21:10", "09/17 20:00", "09/17 19:50" };
    private const string RunName = "麦麦听说废铁刀和白爆矿在谈恋爱";
    private const string Output = "Docs/SaveUIConcepts";
    private const string Prefabs = "Assets/Design/SaveUIConcepts";
    private static readonly List<string> audit = new();

    [MenuItem("Tools/存档/导出四版 UI 方案")]
    public static void Export()
    {
        if (Application.isBatchMode) EditorSceneManager.OpenScene("Assets/Scenes/StartScene.unity");
        Directory.CreateDirectory(Output); Directory.CreateDirectory(Prefabs);
        font = AssetDatabase.LoadAssetAtPath<Font>("Assets/Art/Font/tianwangxingxiangsu.fontsettings");
        var sprites = AssetDatabase.LoadAllAssetsAtPath("Assets/Art/Textures/UI.psd").OfType<Sprite>().ToArray();
        panel = sprites.First(s => s.name == "UI_Panel"); frame = sprites.First(s => s.name == "UI_HoveredFrame");
        var previous = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
        UnityEngine.SceneManagement.SceneManager.SetActiveScene(scene);
        try
        {
            for (int variant = 0; variant < 4; variant++)
                for (int page = 0; page < 3; page++)
                {
                    root = Rect("Concept", null, 0, 0, 1920, 1080);
                    var c = root.gameObject.AddComponent<Canvas>(); c.renderMode = RenderMode.ScreenSpaceCamera;
                    var scaler = root.gameObject.AddComponent<CanvasScaler>(); scaler.referencePixelsPerUnit = 2;
                    root.gameObject.AddComponent<GraphicRaycaster>();
                    if (page == 0) { if (variant == 0) Archive(); if (variant == 1) Journal(); if (variant == 2) Desktop(); if (variant == 3) Cards(); }
                    else if (page == 1) Creation(variant); else Settings(variant);
                    foreach (var t in root.GetComponentsInChildren<Transform>(true))
                        if (t.name == "Hovered") t.gameObject.SetActive(false);
                    string name = ((char)('A' + variant)) + "-" + new[] { "saves", "creation", "settings" }[page];
                    PrefabUtility.SaveAsPrefabAsset(root.gameObject, Prefabs + "/" + name + ".prefab");
                    Render(name);
                    UnityEngine.Object.DestroyImmediate(root.gameObject);
                }
            File.WriteAllLines(Output + "/render-check.txt", audit);
        }
        finally { UnityEngine.SceneManagement.SceneManager.SetActiveScene(previous); EditorSceneManager.CloseScene(scene, true); }
        AssetDatabase.SaveAssets();
        if (Application.isBatchMode) EditorApplication.Exit(0);
    }
    private static RectTransform Window(string title, float x, float y, float w, float h)
    {
        var obj = (GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Prefabs/UI/Windows/CustomWindow.prefab"), root);
        PrefabUtility.UnpackPrefabInstance(obj, PrefabUnpackMode.OutermostRoot, InteractionMode.AutomatedAction);
        UnityEngine.Object.DestroyImmediate(obj.GetComponent<CustomWindow>());
        UnityEngine.Object.DestroyImmediate(obj.transform.Find("Content").gameObject);
        UnityEngine.Object.DestroyImmediate(obj.transform.Find("ButtonLayout").gameObject);
        foreach (var b in obj.GetComponentsInChildren<DragMoveHandler>(true)) UnityEngine.Object.DestroyImmediate(b);
        foreach (var b in obj.GetComponentsInChildren<ChangeMouse>(true)) UnityEngine.Object.DestroyImmediate(b);
        foreach (var b in obj.GetComponentsInChildren<DoubleClickHandler>(true)) UnityEngine.Object.DestroyImmediate(b);
        foreach (string name in new[] { "MaximizeButton", "MinimizeButton", "OrganizeButton" }) { var t = obj.transform.Find("TopBar/" + name); if (t != null) t.gameObject.SetActive(false); }
        obj.transform.Find("TopBar/CloseButton").gameObject.SetActive(true);
        foreach (var text in obj.transform.Find("TopBar").GetComponentsInChildren<Text>(true)) if (text.name == "Name") { text.text = title; text.rectTransform.sizeDelta = new Vector2(w - 180, 40); }
        obj.transform.Find("Frame").gameObject.SetActive(true);
        var r = (RectTransform)obj.transform; Place(r,x,y,w,h); return r;
    }
    private static RectTransform Rect(string name, Transform parent, float x,float y,float w,float h)
    { var r = new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>(); r.SetParent(parent,false); Place(r,x,y,w,h); return r; }
    private static void Place(RectTransform r,float x,float y,float w,float h)
    { r.anchorMin = r.anchorMax = new Vector2(0,1); r.pivot = new Vector2(0,1); r.anchoredPosition = new Vector2(x,-y); r.sizeDelta = new Vector2(w,h); }
    private static void Stretch(RectTransform r) { r.anchorMin = Vector2.zero; r.anchorMax = Vector2.one; r.offsetMin = r.offsetMax = Vector2.zero; }
    private static Image Art(RectTransform r, Sprite sprite, Color? color = null)
    { var i = r.gameObject.AddComponent<Image>(); i.sprite=sprite; i.type=Image.Type.Sliced; i.color=color??Color.white; i.raycastTarget=false; return i; }
    private static RectTransform Box(Transform p,float x,float y,float w,float h,bool selected=false)
    { var r=Rect("Panel",p,x,y,w,h); Art(r,panel); if(selected) Outline(r); return r; }
    private static void Outline(RectTransform p) { var r=Rect("Selection",p,0,0,0,0); Stretch(r); Art(r,frame,Accent); }
    private static Text Label(Transform p,string value,float x,float y,float w,float h,int size=24,Color? color=null,TextAnchor align=TextAnchor.MiddleLeft)
    { var r=Rect("Text",p,x,y,w,h); var t=r.gameObject.AddComponent<Text>(); t.text=value; t.font=font; t.fontSize=size; t.color=color??Color.white; t.alignment=align; t.raycastTarget=false; t.supportRichText=false; t.horizontalOverflow=HorizontalWrapMode.Wrap; t.verticalOverflow=VerticalWrapMode.Truncate; return t; }
    private static void Button(Transform p,string text,float x,float y,float w=128,float h=44,bool selected=false)
    {
        var obj=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Prefabs/UI/Controls/Button/CustomWindowButton.prefab"),p);
        foreach(var m in obj.GetComponentsInChildren<ChangeMouse>(true)) UnityEngine.Object.DestroyImmediate(m);
        Place((RectTransform)obj.transform,x,y,w,h);
        var normal=Rect("NormalFrame",obj.transform,0,0,w,h); Art(normal,panel); normal.SetAsFirstSibling();
        var b=obj.GetComponent<HoverableButton>(); b.text.text=text; b.text.fontSize=24; b.useUnscaledTime=true;
        obj.transform.Find("Hovered").gameObject.SetActive(false);
        if(selected) Outline((RectTransform)obj.transform);
    }
    private static void Tag(Transform p,string text,float x,float y,float w=78,bool active=false)
    { var b=Box(p,x,y,w,32); Label(b,text,4,0,w-8,32,20,active?Accent:Muted,TextAnchor.MiddleCenter); }
    private static void Filters(Transform p,float x,float y,int width=108)
    { for(int i=0;i<4;i++) Button(p,new[]{"全部","自动","手动","退出"}[i],x+i*(width+10),y,width,40,i==0); }
    private static void Scroll(Transform p,float x,float y,float height)
    {
        var obj=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Prefabs/UI/Controls/ScrollView/ScrollbarVertical.prefab"),p);
        Place((RectTransform)obj.transform,x,y,26,height); obj.GetComponent<Scrollbar>().size=.65f;
    }
    private static void Header(Transform p,float w,string name=RunName)
    { Label(p,name,32,84,w-420,40,28); Tag(p,"普通模式",w-370,88,108); Button(p,"周目管理",w-240,84,200); }
    private static void Footer(Transform p,float w,float y,string hint="已选择：驾驶舱 · 第14天 14:30")
    { Label(p,hint,32,y,w-550,48,22,Muted); Button(p,"删除记录",w-490,y,130,48); Button(p,"返回",w-348,y,112,48); Button(p,"读取此记录",w-224,y,192,48,true); }
    private static void LocationIcon(Transform p,int index,float x,float y,float size=64)
    {
        string place=new[]{"驾驶室","动力舱","维生舱","驾驶室","飞船外壳","动力舱"}[index];
        var asset=AssetDatabase.LoadAssetAtPath<UnityEngine.Object>("Assets/Resources/ScriptableObject/Place/"+place+".asset");
        if(asset==null)return;
        var sprite=new SerializedObject(asset).FindProperty("placeImage").objectReferenceValue as Sprite;
        var i=Art(Rect("PlaceIcon",p,x,y,size,size),sprite); i.type=Image.Type.Simple; i.preserveAspect=true;
    }
    private static void Archive()
    {
        var p=Window("航行档案",250,135,1420,810); Header(p,1420);
        Button(p,"周目列表",32,148,146,40); Filters(p,202,148); Label(p,"最近保存优先",1140,148,220,40,22,Muted,TextAnchor.MiddleRight);
        Label(p,"地点",58,211,250,34,20,Muted); Label(p,"游戏时间",350,211,330,34,20,Muted); Label(p,"类型",790,211,140,34,20,Muted); Label(p,"保存于",1040,211,240,34,20,Muted);
        for(int i=0;i<6;i++) { var row=Box(p,32,254+i*66,1310,58,i==0); Label(row,Places[i],24,0,260,58,26); Label(row,"温和季 · "+Times[i],318,0,410,58,24); Tag(row,Kinds[i],760,13); Label(row,RealTimes[i],1008,0,230,58,22,Muted); }
        Scroll(p,1354,254,388); Label(p,"6 / 12 条记录",32,660,400,36,20,Muted); Footer(p,1420,726);
    }
    private static void Journal()
    {
        var p=Window("航行日志",350,100,1220,880); Header(p,1220); Filters(p,32,146,112);
        Label(p,"温和季",32,212,140,32,20,Muted); Label(p,"第14天",32,246,160,48,32); Label(p,"14:30",32,300,160,34,26,Accent);
        var line=Rect("Timeline",p,205,223,4,474); Art(line,frame,new Color(.4f,.4f,.4f));
        var a=Box(p,234,212,930,164,true); LocationIcon(a,0,24,30,72); Label(a,"驾驶舱",120,20,400,40,30); Tag(a,"手动",810,24); Label(a,"温和季 · 第14天 14:30",120,66,600,34,24); Label(a,"09/18 14:30 保存   ·   累计游玩 3小时42分",120,114,750,30,20,Muted);
        for(int i=1;i<3;i++) { Label(p,i==1?"14:20":"12:05",48,404+(i-1)*76,140,38,24,Muted); var b=Box(p,234,394+(i-1)*76,930,64); Label(b,Places[i],24,0,550,64,26); Tag(b,Kinds[i],810,16); }
        Label(p,"第13天",32,596,160,48,32); Label(p,"23:10",48,650,140,36,24,Muted);
        var c=Box(p,234,606,930,80); Label(c,"驾驶舱",24,0,500,80,26); Tag(c,"手动",810,24);
        Scroll(p,1178,212,496); Label(p,"向下滚动查看更早的航行记录",234,710,850,32,20,Muted); Footer(p,1220,796,"已选择第14天的手动记录");
    }
    private static void Desktop()
    {
        var left=Window("周目",166,190,388,704);
        Button(left,"新建周目",24,82,164); Button(left,"导入",200,82,164);
        Label(left,"最近游玩",24,142,300,30,20,Muted);
        string[] runs={RunName,"麦麦制作了废铁刀","麦麦把燃素塞进了冰箱","麦麦正在研究矿石释氧机"};
        for(int i=0;i<4;i++) { var r=Box(left,24,186+i*118,314,104,i==0); Label(r,runs[i],16,8,282,60,24); Label(r,i==0?"普通 · 第14天 · 今天":"普通 · 第"+(9-i)+"天 · 09/17",16,68,282,28,20,Muted); }
        Scroll(left,350,186,464);
        var right=Window("保存记录",578,135,1176,810);
        Label(right,RunName,32,84,1080,40,28); Label(right,"普通模式   ·   累计游玩 3小时42分",32,128,750,32,22,Muted);
        Filters(right,32,190,106); Button(right,"复制",780,190,108,40); Button(right,"分享",900,190,108,40); Button(right,"更多",1020,190,124,40);
        for(int i=0;i<5;i++) { var r=Box(right,32,260+i*74,1080,64,i==0); Label(r,Places[i],20,0,230,64,26); Label(r,"温和季 · "+Times[i],278,0,450,64,24); Tag(r,Kinds[i],900,16); }
        Scroll(right,1122,260,360); Label(right,"保存于 2026/09/18 14:30   ·   游戏版本 0.5.4",32,646,1040,34,22,Muted); Footer(right,1176,726,"选中 1 条记录");
    }
    private static void Cards()
    {
        var p=Window("航行记录",230,100,1460,880); Header(p,1460); Filters(p,32,146,110); Button(p,"切换周目",1198,146,230,40);
        for(int i=0;i<6;i++)
        {
            var card=Box(p,32+(i%3)*464,220+(i/3)*250,442,226,i==0);
            LocationIcon(card,i,24,24,70); Label(card,Places[i],116,24,300,40,30); Tag(card,Kinds[i],116,72,82);
            Label(card,"温和季",24,120,370,26,20,Muted); Label(card,Times[i],24,154,390,34,26);
            Label(card,RealTimes[i]+" 保存",24,194,390,26,20,Muted);
        }
        Scroll(p,1426,220,476); Label(p,"显示 6 / 12 条保存记录",32,732,600,34,20,Muted); Footer(p,1460,796);
    }
    private static void NameInput(Transform p,float x,float y,float width)
    { Box(p,x,y,width-132,52); Label(p,"麦麦正在研究矿石释氧机",x+14,y+2,width-156,48,26); Button(p,"随机",x+width-120,y,120,52); }
    private static void ModeCards(Transform p,float x,float y,float width)
    {
        float col=(width-20)/2;
        var a=Box(p,x,y,col,166,true); Label(a,"普通模式",20,18,col-40,36,28); Label(a,"保留多个保存点\n死亡后可以回档",20,66,col-40,72,24,Muted);
        var b=Box(p,x+col+20,y,col,166); Label(b,"硬核模式",20,18,col-40,36,28); Label(b,"仅保留最新进度\n死亡后删除周目",20,66,col-40,72,24,Muted);
    }
    private static void Creation(int v)
    {
        var p=Window("创建周目",v==2?564:370,170,v==2?1120:1180,740);
        float w=v==2?1120:1180;
        if(v==0)
        {
            Label(p,"新的周目",32,86,900,46,34); Label(p,"周目名称",32,172,200,52,24); NameInput(p,250,172,w-282);
            Label(p,"游戏模式",32,266,200,48); Button(p,"普通",250,266,164,48,true); Button(p,"硬核",430,266,164,48); Label(p,"死亡后可读取历史保存点",250,326,w-282,36,22,Muted);
            Label(p,"新手教程",32,404,200,48); Button(p,"开启",250,404,164,48,true); Button(p,"跳过",430,404,164,48);
        }
        else if(v==1)
        {
            Label(p,"麦麦的新一段旅途",40,88,1060,48,34); Label(p,"为这段故事取一个名字",40,156,1060,34,22,Muted); NameInput(p,40,202,w-80);
            ModeCards(p,40,300,w-80); Label(p,"初次游玩建议保留教程",40,510,730,44,24,Muted); Button(p,"教程：开启",w-246,510,206,44,true);
        }
        else if(v==2)
        {
            var nav=Window("新周目",190,218,350,530); Label(nav,"创建流程",24,94,302,40,28); Button(nav,"1  基本信息",24,162,302,56,true); Label(nav,"名称、模式与教程",24,238,302,68,24,Muted); Label(nav,"完成设置后即可开始",24,374,302,68,22,Muted);
            Label(p,"基本信息",32,86,900,46,34); Label(p,"周目名称",32,158,900,36); NameInput(p,32,206,w-64); ModeCards(p,32,300,w-64); Label(p,"新手教程",32,520,700,44); Button(p,"开启",w-204,520,172,44,true);
        }
        else
        {
            Label(p,"开始新的故事",32,86,900,46,34); Label(p,"周目名称",32,158,900,36); NameInput(p,32,204,w-64); ModeCards(p,32,300,w-64); Label(p,"新手教程",32,518,800,44); Button(p,"开启",w-208,518,176,44,true);
        }
        Label(p,"名称和设置确认后开始游戏",32,616,w-64,34,20,Muted); Button(p,"返回",w-392,668,140,48); Button(p,"开始游戏",w-236,668,204,48,true);
    }
    private static void SettingRows(Transform p,float x,float y,float width)
    {
        var r=Box(p,x,y,width,76); Label(r,"自动保存",20,12,width-200,52,26); Button(r,"开启",width-154,16,132,44,true);
        r=Box(p,x,y+94,width,96); Label(r,"保存间隔",20,10,width-300,38,26); Label(r,"按实际游玩时间计算",20,51,width-300,28,20,Muted); Button(r,"－",width-262,26,52); Label(r,"10 分钟",width-204,26,124,44,24,null,TextAnchor.MiddleCenter); Button(r,"＋",width-74,26,52);
        r=Box(p,x,y+206,width,96); Label(r,"自动记录上限",20,10,width-300,38,26); Label(r,"手动与退出记录永久保留",20,51,width-300,28,20,Muted); Button(r,"－",width-262,26,52); Label(r,"10 条",width-204,26,124,44,24,null,TextAnchor.MiddleCenter); Button(r,"＋",width-74,26,52);
    }
    private static void Settings(int v)
    {
        float w=v==2?1100:1260;
        var p=Window("设置",v==2?574:330,140,w,800);
        var cats=new[]{"声音","存档","阅读","显示"};
        if(v==0)
        { for(int i=0;i<4;i++) Button(p,cats[i],32+i*156,90,144,48,i==1); Label(p,"存档设置",32,170,1000,46,32); SettingRows(p,32,244,w-64); }
        else if(v==1)
        { Label(p,"存档",40,90,800,48,36); Label(p,"设定麦麦记录旅途的频率",40,144,1000,36,24,Muted); for(int i=0;i<4;i++) Button(p,cats[i],40+i*156,204,144,44,i==1); SettingRows(p,40,292,w-80); }
        else if(v==2)
        { var n=Window("设置分类",210,226,338,570); for(int i=0;i<4;i++) Button(n,cats[i],24,96+i*92,290,64,i==1); Label(p,"存档设置",32,90,1000,48,34); Label(p,"偏好设置对所有周目生效",32,152,1000,36,24,Muted); SettingRows(p,32,238,w-64); }
        else
        { for(int i=0;i<4;i++) Button(p,cats[i],32+i*300,90,284,72,i==1); Label(p,"存档",32,202,900,44,32); SettingRows(p,32,274,w-64); }
        Label(p,"更改即时生效",32,680,w-500,46,22,Muted); Button(p,"恢复本页默认",w-436,716,216,48); Button(p,"完成",w-204,716,172,48,true);
    }
    private static void Render(string name)
    {
        var cameraObject=new GameObject("ConceptCamera"); var camera=cameraObject.AddComponent<Camera>(); camera.clearFlags=CameraClearFlags.SolidColor; camera.backgroundColor=new Color32(17,17,17,255); camera.cullingMask=1<<31;
        foreach(var t in root.GetComponentsInChildren<Transform>(true))t.gameObject.layer=31;
        var canvas=root.GetComponent<Canvas>(); canvas.worldCamera=camera; canvas.planeDistance=1;
        var texture=new RenderTexture(1920,1080,24); camera.targetTexture=texture;
        Canvas.ForceUpdateCanvases(); camera.Render();
        var before=RenderTexture.active; RenderTexture.active=texture;
        var image=new Texture2D(1920,1080,TextureFormat.RGB24,false); image.ReadPixels(new Rect(0,0,1920,1080),0,0); image.Apply(); File.WriteAllBytes(Output+"/"+name+".png",image.EncodeToPNG());
        foreach(var text in root.GetComponentsInChildren<Text>()) if(text.preferredHeight>text.rectTransform.rect.height+3) audit.Add(name+" overflow: "+text.text+" "+text.preferredHeight+"/"+text.rectTransform.rect.height);
        audit.Add(name+" rendered at 1920x1080");
        RenderTexture.active=before; camera.targetTexture=null; UnityEngine.Object.DestroyImmediate(image); UnityEngine.Object.DestroyImmediate(texture); UnityEngine.Object.DestroyImmediate(cameraObject);
    }
}
